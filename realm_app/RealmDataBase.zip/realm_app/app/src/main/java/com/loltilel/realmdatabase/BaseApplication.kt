package com.loltilel.realmdatabase

import android.app.Application

class BaseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}